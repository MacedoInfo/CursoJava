/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxapplication5;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 *
 * @author Macedo
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label lblMenssagem;
    
            
    @FXML
    private void clicouBotao (ActionEvent event) {
        lblMenssagem.setText("É Eu sua danada");
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
